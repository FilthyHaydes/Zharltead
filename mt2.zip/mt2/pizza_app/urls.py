from django.contrib import admin
from django.urls import path
from pizza_app import views

urlpatterns = [
    path('', views.home, name='home'),
    path('order/', views.order_list, name='order_list'),
    path('order/<int:id>/', views.order_detail, name='order_detail'),
    path('pizza/', views.pizza_list, name='pizza_list'),
    path('pizza/<int:id>/', views.pizza_detail, name='pizza_detail'),
    path('pizza/<int:id>/edit', views.pizza_edit, name='pizza_edit'),
    path('pizza/<int:id>/update', views.pizza_update, name='pizza_update'),
    path('login', views.login, name='login'),
]
