from django.db import models


# Pizza Model
class Pizza(models.Model):
    name = models.CharField(max_length=255)
    description = models.TextField()


# Order Model
class Order(models.Model):
    name = models.CharField(max_length=255)
    address = models.CharField(max_length=255)
    notes = models.TextField(null=True, blank=True)

    # One-to-many relationship
    pizza = models.ForeignKey(Pizza, related_name='orders', on_delete=models.CASCADE)


# PizzaOrder Model
class PizzaOrder(models.Model):
    # One-to-many relationship with Order
    pizza = models.ForeignKey(Pizza, related_name='orders', on_delete=models.CASCADE)
    # One-to-many relationship with Pizza (Order can have multiple pizzas)
    order = models.ForeignKey(Order, related_name='orders', on_delete=models.CASCADE, blank=True, null=True)
    # One-to-one relationship with User
    customer = models.ForeignKey(User, related_name='pizza_orders', on_delete=models.CASCADE)
    # Creation timestamp
    created_at = models.DateTimeField(auto_now_add=True)

