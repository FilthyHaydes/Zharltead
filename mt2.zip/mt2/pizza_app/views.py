from django.shortcuts import render
from django.template import RequestContext
from django.views.generic.list import ListView
from django.contrib import messages
from pizza_app.models import Order, Pizza
from pizza_app.forms import OrderForm

class OrderListView(ListView):
    model = Order
    template_name = 'orders/order_list.html'
    context_object_name = 'orders'

    def get_queryset(self):
        return Order.objects.filter(customer=self.request.user)

    @method_decorator(transaction.atomic)
    def get_context_data(self, **kwargs):
        context = super(OrderListView, self).get_context_data(**kwargs)
        if self.request.method == 'POST':
            order_form = OrderForm(self.request.POST)
            if order_form.is_valid():
                # Get the saved order
                saved_order = order_form.save(commit=False)
                # Get the user who placed the order
                user = self.request.user
                # Save the order and redirect to the order list page
                saved_order.customer = user
                saved_order.save()
                messages.success(self.request, f"Your order has been placed!")
                return render(self.request, 'orders/order_list.html', {'saved_order': saved_order})
        else:
            context.update({'form': order_form.as_p})
        return context

from .forms import OrderForm
from .models import Order
from django.contrib.auth.mixins import LoginRequiredMixin
from django.views.generic import CreateView
from django.http import HttpResponseRedirect

class OrderCreateView(LoginRequiredMixin, CreateView):
    model = Order
    form_class = OrderForm
    def get_context_data(self, **kwargs):
        context = super(OrderCreateView, self).get_context_data(**kwargs)
        if self.request.method == 'POST':
            order_form = OrderForm(self.request.POST)
            if order_form.is_valid():
                # Get the saved order
                order = order_form.save(commit=False)
                # Get the user who placed the order
                user = self.request.user
                # Add the user to the order as the customer
                order.customer = user
                order.save()
                messages.success(self.request, f"Your order has been placed!")
                return HttpResponseRedirect(reverse('pizza_app:orders_list'))
        context.update({'order_form': order_form.as_p, 'request_method': self.request.method})
        return context



from django.shortcuts import render
from django.http import HttpResponse
from .models import Order
from .forms import OrderForm


class OrderCreateView(FormView, TemplateView):
    form_class = OrderForm
    template_name = 'orderform.html'

    def get_success_url(self):
        # Return the URL to the order list after an order is successfully created
        if self.request.method == 'POST':
            return reverse('pizzapp:orders_list')
        else:
            return None

    def get_form_kwargs(self):
        # Pass the user object to the form so that it can pre-fill the customer field
        kwargs = super().get_form_kwargs()
        if self.request.user:
            kwargs['initial']['customer'] = self.request.user
        return kwargs

    def get_context_data(self, **kwargs):
        # Pass the user object to the context so that it can be used in the template
        if self.request.user:
            context = super().get_context_data(**kwargs)
            context['current_user'] = self.request.user
            return context

    def form_valid(self, form):
        # Bind the form data to a new Order object and save it
        order = Order.objects.create(**form.cleaned_data)
        messages.success(self.request, f'Your order has been placed!')
        return redirect('pizzapp:orders_list')

    def get_queryset(self):
        return Order.objects.all()

    def get_object_list(self):
        # Return a list of all Order objects
        return Order.objects.all()

    def get(self, request, *args, **kwargs):
        # Handle GET requests
        form = self.get_form()
        if form.is_valid():

