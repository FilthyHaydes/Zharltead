from rest_framework import serializers
from pizza_app.models import Pizza, Order, PizzaOrder

class PizzaSerializer(serializers.ModelSerializer):
    class Meta:
        model = Pizza
        fields = ['id', 'name', 'price', 'desc', 'image']

class OrderSerializer(serializers.ModelSerializer):
    pizzas = PizzaSerializer(many=True)
    class Meta:
        model = Order
        fields = ['id', 'date', 'time', 'total', 'toppings', 'pizza']

class PizzaOrderSerializer(serializers.ModelSerializer):
    pizza_orders = OrderSerializer(many=True)
    class Meta:
        model = PizzaOrder
        fields = ['id', 'pizza', 'order', 'price', 'quantity']
