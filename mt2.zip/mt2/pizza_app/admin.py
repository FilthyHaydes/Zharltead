from django.contrib import admin
from models import Pizza, Order, PizzaOrder

# Register the model admin sites
admin.site.register(Pizza)
admin.site.register(Order)
admin.site.register(PizzaOrder)

